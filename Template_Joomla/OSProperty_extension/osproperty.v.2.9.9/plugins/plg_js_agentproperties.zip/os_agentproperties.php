<?php
// no direct access
defined('_JEXEC') or die('Restricted access');

require_once( JPATH_ROOT .'/components/com_community/libraries/core.php');

class plgCommunityOS_Agentproperties extends CApplications
{
	var $name 		= "OS Property ";
	var $_name		= 'OS Property';
	var $_path		= '';
	var $_user		= '';
	var $_my		= '';

    function plgCommunityOS_Agentproperties(& $subject, $config)
    {
    	$this->_path	= JPATH_BASE .  '/administrator/components/com_osproperty';
		$this->_user	= CFactory::getActiveProfile();
		$this->_my		= CFactory::getUser();			
		parent::__construct($subject, $config);
    }
		
	function onProfileDisplay()
	{	
		require_once JPATH_ROOT.'/administrator/components/com_osproperty/helpers/extrafields.php';
		require_once JPATH_ROOT.'/administrator/components/com_osproperty/helpers/classimage.php';
		require_once JPATH_ROOT.'/administrator/components/com_osproperty/helpers/image.php';
		require_once JPATH_ROOT.'/components/com_osproperty/helpers/helper.php';
		require_once JPATH_ROOT.'/components/com_osproperty/helpers/route.php';
		require_once JPATH_ROOT.'/components/com_osproperty/helpers/common.php';
		require_once JPATH_ROOT.'/components/com_osproperty/helpers/pagination.php';
		require_once JPATH_ROOT.'/components/com_osproperty/classes/template.class.php';
		require_once JPATH_ROOT.'/components/com_osproperty/helpers/googlemap.lib.php';
								
		if( !file_exists( $this->_path .  '/osproperty.php' ) ){			
			$content = "<div class=\"icon-nopost\"><img src='".JURI::base()."components/com_community/assets/error.gif' alt=\"\" /></div>";	
			$content .= "<div class=\"content-nopost\">".JText::_('OS Property is not installed. Please contact site administrator.')."</div>";
		}else{	
					
			$user		= CFactory::getActiveProfile();			
			$userId = $user->id;
			$currentUserId = $this->_my->id ;
			//if ($userId != $currentUserId)
			//	return null;
			$numberRecord = $this->params->get('number_records', 10);
			$rows	= $this->_getProperties($userId, $numberRecord);
			$total = $this->_getTotal($userId) ;	
			$content = $this->_getPropertiesHTML($rows, $userId, $currentUserId, $total) ;
		}	
		return $content;
	}
	/**
	 * Draw HTML for registration history
	 *
	 * @param array $rows
	 * @param int $userId
	 * @param int $currentUserId
	 * @param int $total
	 * @return string
	 */	
	function _getPropertiesHTML($properties, $userId, $currentUserId, $total){			
		global $_jversion,$configs,$configClass,$symbol;
		$db = JFactory::getDBO();
		
		$configClass = OSPHelper::loadConfig();
		
		$lang = & JFactory::getLanguage() ;
		$tag = $lang->getTag();
		if (!$tag)
			$tag = 'en-GB' ;			
		$lang->load('com_osproperty', JPATH_ROOT, $tag);
			
		//$itemId = JRequest::getVar('Itemid');
		$pageNav = new OSPJPagination(count($properties),0,count($properties));
		
		
		$db->setQuery("Select * from #__osrs_themes where published = '1'");
		$theme = $db->loadObject();
		$themename = ($theme->name!= "")? $theme->name:"default";
		$params = $theme->params;
		$params = new JRegistry($params) ;
		$document = JFactory::getDocument();
		$document->addStyleSheet(OspropertyTemplate::livePath()."/style/style.css");
		$tpl = new OspropertyTemplate();
		
		ob_start();
		$tpl->set('params',$params);
		$tpl->set('rows',$properties);
		$tpl->set('pageNav',$pageNav);
		$tpl->set('task',JRequest::getVar('task',''));
		$tpl->set('temp_path_img',OspropertyTemplate::livePath()."/img");
		echo $tpl->fetch("listing.html.tpl.php");
		$output = ob_get_contents();
		ob_end_clean();		
			
		return $output ;					
	}	
	/**
	 * Get list of registration records of the current user
	 *
	 * @param int $userId
	 * @param int $numberRecords
	 * @return array
	 */		 
	function _getProperties($userId, $numberRecords)
	{
		$languages = JFactory::getLanguage();
		$translatable = JLanguageMultilang::isEnabled() && count($languages);
		if($translatable){
			//generate the suffix
			$lang_suffix = OSPHelper::getFieldSuffix();
		}
		$db		= & JFactory::getDBO();
		
		$rows = array();
		$db->setQuery("Select id from #__osrs_agents where user_id = '$userId' and published = '1'");
		$agentId = $db->loadResult();
		if($agentId > 0){
			$sql = "Select p.*,c.name as agent_name,c.photo as agent_photo,c.email as agent_email,d.id as typeid,d.type_name$lang_suffix as type_name,e.country_name from #__osrs_properties as p"
				." INNER JOIN #__osrs_agents as c on c.id = p.agent_id"
				." LEFT JOIN #__osrs_types as d on d.id = p.pro_type"
				." LEFT JOIN #__osrs_countries as e on e.id = p.country"
				." WHERE p.agent_id = '$agentId' AND p.approved = '1' AND p.published = '1' ";
	    	$order_by = " ORDER BY p.created DESC";
			$db->setQuery($sql.$order_by);	
			$rows =  $db->loadObjectList();									
			if(count($rows) > 0){
				$fields = HelperOspropertyCommon::getExtrafieldInList();
				//get the list of extra fields that show at the list
				for($i=0;$i<count($rows);$i++){//for
					$row = $rows[$i];
					
					$pro_name = OSPHelper::getLanguageFieldValue($row,'pro_name');
					$row->pro_name = $pro_name;
					$pro_small_desc = OSPHelper::getLanguageFieldValue($row,'pro_small_desc');
					$row->pro_small_desc = $pro_small_desc;
						
					OSPHelper::generateAlias('property',$row->id,$row->pro_alias);
					$alias = $row->pro_alias;
					$new_alias = OSPHelper::generateAlias('property',$row->id,$row->pro_alias);
					if($alias != $new_alias){
						$db->setQuery("Update #__osrs_properties set pro_alias = '$new_alias' where id = '$row->id'");
						$db->query();
					}
					
					$category_name = OSPHelper::getCategoryNamesOfPropertyWithLinks($row->id);
					$row->category_name = $category_name;
					
					$category_name = OSPHelper::getCategoryNamesOfProperty($row->id);
					$category_nameArr = explode(" ",$category_name);
					$row->category_name_short = "";
					//echo count($category_nameArr);
					//echo "<BR />";
					if(count($category_nameArr) > 4){
						for ($j=0;$j<4;$j++){
							$row->category_name_short .= $category_nameArr[$j]." ";
						}
						$row->category_name_short .= "...";
						//echo $row->category_name;
					}else{
						$row->category_name_short = $category_name;
					}
					
					$query = $db->getQuery(true);
					$query->select("*")->from("#__osrs_property_open")->where("pid='".$row->id."' and end_to > '".date("Y-m-d H:i:s",time())."'")->order("start_from");
					$db->setQuery($query);
					$openInformation = $db->loadObjectList();
					$row->openInformation = $openInformation;
					
					if($row->number_votes > 0){
						$rate = round($row->total_points/$row->number_votes,2);
						if($rate <= 1){
							$row->cmd = JText::_('OS_POOR');
						}elseif($rate <= 2){
							$row->cmd = JText::_('OS_BAD');
						}elseif($rate <= 3){
							$row->cmd = JText::_('OS_AVERGATE');
						}elseif($rate <= 4){
							$row->cmd = JText::_('OS_GOOD');
						}elseif($rate <= 5){
							$row->cmd = JText::_('OS_EXCELLENT');
						}
						$row->rate = $rate;
					}else{
						$row->rate = '';
						$row->cmd  = JText::_('OS_NOT_SET');
					}
					
					$db->setQuery("Select * from #__osrs_comments where pro_id = '$row->id' and published = '1' order by created_on desc");
					$row->commentObject = $db->loadObject();
					
					
					//get field data
					if(count($fields) > 0){
						$fieldArr = array();
						$k 		  = 0;
						for($j=0;$j<count($fields);$j++){
							$field = $fields[$j];
							$value = HelperOspropertyFieldsPrint::showField($field,$row->id);
							if($value != ""){
								if($field->displaytitle == 1){
									$fieldArr[$k]->label = OSPHelper::getLanguageFieldValue($field,'field_label');
								}
								$fieldArr[$k]->fieldvalue = $value;
								$k++;
							}
						}
						$row->fieldarr = $fieldArr;
					}
					//process photo
					$db->setQuery("select count(id) from #__osrs_photos where pro_id = '$row->id'");
					$count = $db->loadResult();
					if($count > 0){
						$row->count_photo = $count;
						$db->setQuery("select image from #__osrs_photos where pro_id = '$row->id' order by ordering limit 1");	
						$picture = $db->loadResult();
						if($picture != ""){
						
							if(file_exists(JPATH_ROOT.'/images/osproperty/properties/'.$row->id.'/medium/'.$picture)){
								$row->photo = JURI::root().'images/osproperty/properties/'.$row->id.'/medium/'.$picture;	
							}else{
								$row->photo = JURI::root()."/components/com_osproperty/images/assets/nopropertyphoto.png";
							}
						}else{
							$row->photo = JURI::root()."/components/com_osproperty/images/assets/nopropertyphoto.png";
						}
							
					}else{
						$row->count_photo = 0;
						$row->photo = $row->photo = JURI::root()."/components/com_osproperty/images/assets/nopropertyphoto.png";;
					}//end photo
					
					$count = 0;
					if($row->count_photo > 0){
						$db->setQuery("Select * from #__osrs_photos where pro_id = '$row->id'");
						$photos = $db->loadObjectList();
						$photoArr = array();
						for($j=0;$j<count($photos);$j++){
							$photoArr[$j] = $photos[$j]->image;
							if(file_exists(JPATH_ROOT.'/images/osproperty/properties/'.$row->id.'/medium/'.$photos[$j]->image)){
								$count++;
							}
						}
						$row->photoArr = $photoArr;
						$row->count_photo = $count;
					}
					//get state
					$db->setQuery("Select state_name$lang_suffix as state_name from #__osrs_states where id = '$row->state'");
					$row->state_name = $db->loadResult();
					
					//get country
					$db->setQuery("Select country_name from #__osrs_countries where id = '$row->country'");
					$row->country_name = $db->loadResult();
					
					//rating
					if($configClass['show_rating'] == 1){
						if($row->number_votes > 0){
							$points = round($row->total_points/$row->number_votes);
							ob_start();
							for($j=1;$j<=$points;$j++){
								?>
								<img src="<?php echo JURI::root()?>components/com_osproperty/images/assets/star1.png">
								<?php
							}
							for($j=$points+1;$j<=5;$j++){
								?>
								<img src="<?php echo JURI::root()?>components/com_osproperty/images/assets/star2.png">
								<?php
							}
							$row->rating = ob_get_contents();
							ob_end_clean();
							
						}else{
							ob_start();
							for($j=1;$j<=5;$j++){
								?>
								<img src="<?php echo JURI::root()?>components/com_osproperty/images/assets/star2.png">
								<?php
							}
							$row->rating = ob_get_contents();
							ob_end_clean();
						} //end rating
					}
					
					//comments
					$db->setQuery("Select count(id) from #__osrs_comments where pro_id = '$row->id'");
					$ncomment = $db->loadResult();
					if($ncomment > 0){
						$row->comment = $ncomment;
					}else{
						$row->comment = 0;
					}
					
				}//for
			}//if rows > 0
		}	
		return $rows;
	}
	/**
	 * Get total number of registration records
	 *
	 */
	function _getTotal($userId) {
		$db		= & JFactory::getDBO();
		$sql	 = "SELECT count(p.id) FROM #__osrs_properties AS p
    				WHERE p.agent_id = '$userId' AND p.approved = '1' AND p.published = '1' 
    				";    
    	$order_by = " ORDER BY p.created DESC";
		$db->setQuery($sql);		
		return $db->loadResult();
	}		
}
