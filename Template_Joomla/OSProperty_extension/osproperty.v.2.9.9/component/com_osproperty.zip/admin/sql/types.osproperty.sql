INSERT INTO `#__osrs_types` (`id`, `type_name`, `type_alias`, `type_description`, `published`) VALUES
(1, 'for sale', 'for-sale', '', 1),
(2, 'For lease', 'for-lease', '', 1),
(3, 'For rent', 'for-rent', '', 1),
(4, 'Pending', '', '', 1),
(5, 'Sold', '', '', 1),
(6, 'For sale or lease', '', '', 1);